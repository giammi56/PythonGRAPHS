#!/usr/bin/env python

import sys


def fibonacci_generator_plain():
    """This function is one possible solution to exercise 6."""
    prev_prev = 1
    yield prev_prev
    prev = 1
    yield prev
    while True:
        current = prev + prev_prev
        yield current
        prev_prev, prev = prev, current

def fibonacci_generator_with_index():
    """This function is one possible solution to exercise 6."""
    prev_prev = 1
    yield (1, prev_prev)
    prev = 1
    yield (2, prev)
    idx = 3
    while True:
        current = prev + prev_prev
        yield (idx, current)
        prev_prev, prev = prev, current
        idx += 1

fibonacci_generator = fibonacci_generator_plain


def main(n):
    """Example of usage of 'fibonacci_generator'."""
    for idx, fibonacci_number in enumerate(fibonacci_generator()):
        print(fibonacci_number, end=", ")
        if idx+1 == n:
            break
    print()


if __name__ == "__main__":
    try:
        n = int(sys.argv[1])
    except IndexError:
        print("Usage: {script} <int>".format(script=sys.argv[0]), file=sys.stderr)
        print("and the first <int> Fibonacci numbers will be returned", file=sys.stderr)
    else:
        sys.exit(main(n))

