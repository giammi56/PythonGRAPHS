#!/bin/env python

class Vector:
    def __init__(self, *coordinates):
        self.coordinates = coordinates

    def __len__(self):
        return sum([abs(_) for _ in self.coordinates])

    def __str__(self):
        return str(self.coordinates)

    def __repr__(self):
        return "Vector{}".format(self.coordinates)

    def __call__(self):
        raise TypeError(
            "Why are you calling a vector? What do you expect me to do?"
        )

    def __add__(self, other):
        coordinates = [i+j for i,j in zip(self.coordinates, other.coordinates)]
        return Vector(*coordinates)

    def __mul__(self, other):
        coordinates = [i*other for i in self.coordinates]
        return Vector(*coordinates)

    def __rmul__(self, other):
        return self.__mul__(other)

    
if __name__ == "__main__":
    a = Vector(8,1)
    a()

    
