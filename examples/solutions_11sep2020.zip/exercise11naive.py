#!/bin/env python

class Happy:
    _SAD = "sad"
    _HAPPY = "happy"
    
    def __init__(self, name):
        self._name = name
        self._state = self._HAPPY
        
    def greet(self):
        if self._state == self._HAPPY:
            msg = '"Hellloooo!"'
        else:
            msg = '"Get lost!"'
        print (self._name, 'says', msg)
        
    def sing(self):
        if self._state == self._HAPPY:
            msg = 'La-la-laaaaah!'
        else:
            msg = self._name + ' is to depressed to sing.'
        print (msg)
        
    def change(self):
        if self._state == self._SAD:
            self._state = self._HAPPY
        else:
            self._state = self._SAD


if __name__ == "__main__":
    p = Happy('Petros')
    p.greet()
    p.sing()
    p.change()
    p.greet()
    p.sing()
    p.change()    
    p.greet()
    p.sing()
