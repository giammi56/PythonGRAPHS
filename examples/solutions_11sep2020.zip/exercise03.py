#!/usr/bin/env python

first_password_msg = "Password: "
second_password_msg = "Please, enter again the password: "
first_password = input(first_password_msg)
second_password = input(second_password_msg)

while first_password != second_password:
    print("Passwords do not match.")
    first_password = input(first_password_msg)
    second_password = input(second_password_msg)

print("Thank you")

