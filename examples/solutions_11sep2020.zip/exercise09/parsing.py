#!/bin/env python

def simple_parser(input_string):
    colon_splitted = input_string.split(":")
    if len(colon_splitted) == 2:
        args = colon_splitted[1].split(",")
        output = (colon_splitted[0],)+tuple(args)
    elif input_string == "exit":
        output = input_string
    else:
        output = None
    return output
