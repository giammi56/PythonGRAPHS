#!/bin/env python

from funcs import deep_maths

def compute(function_name, *args):
    return deep_maths[function_name](*[float(i) for i in args])


