#!/bin/env python

import funcs

def compute(function_name, *args):
    return funcs.__dict__[function_name](*[float(i) for i in args])


