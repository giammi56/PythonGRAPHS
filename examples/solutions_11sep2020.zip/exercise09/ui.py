#!/bin/env python

import readline

from parsing import simple_parser
from real_work import compute


def interactive_input():
    while True:
        input_string = input("> ")
        parsed_input = simple_parser(input_string)
        if parsed_input is None:
            continue
        elif parsed_input == "exit":
            return
        else:
            print(compute(*parsed_input))
