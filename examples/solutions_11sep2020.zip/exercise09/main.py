#!/bin/env python

import sys

from ui import interactive_input


if __name__ == "__main__":
    sys.exit(interactive_input())
