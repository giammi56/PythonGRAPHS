#!/bin/env python

def fun1(a, b, c):
    return a*b+c

def fun2(x, *coeffs):
    return sum([coeff*x**(i+1) for i, coeff in enumerate(coeffs)])
    
def fun3(x, a):
    import math
    return a*math.sin(x)/x

