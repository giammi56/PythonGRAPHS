#!/bin/env python

class Happy:
    def __init__(self, name):
        self._name = name
    def greet(self):
        print (self._name, 'says "Hellloooo!"')
    def sing(self):
        print ('La-la-laaaaah!')
    def change(self):
        self.__class__ = Sad

class Sad:
    def greet(self):
        print (self._name, 'says "Get lost!"')
    def sing(self):
        print (self._name, 'says "Is too depressed to sing"')
    def change(self):
        self.__class__ = Happy


if __name__ == "__main__":
    p = Happy('Petros')
    p.greet()
    p.sing()
    p.change()
    p.greet()
    p.sing()
    p.change()    
    p.greet()
    p.sing()
