#!/bin/env python

class Distance:
    _unit_factors = {"m": 1, "cm": 0.01}
    _default_units = "m"
    def __init__(self, value, units=_default_units):
        self.units = units
        self.value_in_m = value*self._unit_factors[self.units]

    def normalize(self, units=_default_units):
        return self.value_in_m/self._unit_factors[units]
    
    def __str__(self):
        return "{} {}".format(self.normalize(self.units), self.units)

    def __add__(self, other):
        value = self.normalize() + other.normalize()
        res = Distance(value)
        return res
    
        
if __name__ == "__main__":
    a = Distance(3, units="m")
    b = Distance(5, units="cm")
    c=a+b
    print(c)# 3.05 m
    c.units = "cm"
    print(c)# 305.0 cm
    # Of course, the following works the same:
    d = Distance(13.01, "m")
    e = Distance(455.09, "cm")
    g=d+e
    print(g)# 17.5609 m
    g.units = "cm"
    print(g)# 1756.09 cm
