#!/bin/env python

import funcs

def compute(function_name, *args):
    try:
        result = funcs.__dict__[function_name](*[float(i) for i in args])
    except TypeError as e:
        result = "   {}".format(e)
    return result


