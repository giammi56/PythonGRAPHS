#!/usr/bin/env python

import sys


def nth_fibonacci(n):
    """This function is one possible (nor particularly elegant) solution to exercise 4."""
    prev = 1
    prev_prev = 1
    f_nth = prev
    for i in range(3,n+1):
        f_nth = prev + prev_prev
        prev_prev = prev
        prev = f_nth
    return f_nth

def main(n):
    for i in range(1,int(n)+1):
        print(nth_fibonacci(i), end=", ")
    print()


if __name__ == "__main__":
    try:
        n = sys.argv[1]
    except IndexError:
        print("Usage: {script} <int>".format(script=sys.argv[0]), file=sys.stderr)
        print("and the first <int> Fibonacci numbers will be returned", file=sys.stderr)
    else:
        sys.exit(main(n))

