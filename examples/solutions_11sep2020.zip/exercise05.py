#!/usr/bin/env python

import sys
from math import sqrt

def check_is_prime(number):
    is_prime = False
    if number > 1:
        for would_be_divisor in range(2,int(sqrt(number))+1):
            if (number % would_be_divisor) == 0:
                break
        else:
            is_prime = True
    return is_prime

def nth_prime(n):
    """This function is one possible (naive) solution to exercise 5."""
    nprimes = 1
    nth_prime = 2
    next_candidate = 3
    while nprimes < n:
        if check_is_prime(next_candidate):
            nth_prime = next_candidate
            nprimes += 1
        next_candidate += 2
    return nth_prime

def main(n):
    for i in range(1,int(n)+1):
        print(nth_prime(i), end=", ")
    print()


if __name__ == "__main__":
    try:
        n = sys.argv[1]
    except IndexError:
        print("Usage: {script} <int>".format(script=sys.argv[0]), file=sys.stderr)
        print("and the first <int> prime numbers will be returned", file=sys.stderr)
    else:
        sys.exit(main(n))

