#!/usr/bin/env python

import sys
from math import sqrt

def check_is_prime(number):
    is_prime = False
    if number > 1:
        for would_be_divisor in range(2,int(sqrt(number))+1):
            if (number % would_be_divisor) == 0:
                break
        else:
            is_prime = True
    return is_prime

def prime_numbers_generator():
    """This function is one possible solution to exercise 7."""
    yield 2
    prime = 3
    yield prime
    candidate = prime+2
    while True:
        if check_is_prime(candidate):
            prime = candidate
            yield prime
        candidate += 2
        
def main(n):
    """Example of usage of 'prime_numbers_generator'."""
    for idx, prime_number in enumerate(prime_numbers_generator()):
        print(prime_number, end=", ")
        if idx+1 == n:
            break
    print()


if __name__ == "__main__":
    try:
        n = int(sys.argv[1])
    except IndexError:
        print("Usage: {script} <int>".format(script=sys.argv[0]), file=sys.stderr)
        print("and the first <int> prime numbers will be returned", file=sys.stderr)
    else:
        sys.exit(main(n))

